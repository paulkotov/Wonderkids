<?php
	$conf['db_host'] = 'localhost';
	$conf['db_name'] = 'wks_test';
	$conf['db_login'] = 'root';
	$conf['db_pwd'] = '';
	$conf['include_dir'][] = '';
	$conf['include_dir'][] = 'lib';
	$conf['include_dir'][] = 'classes';
?>